#pragma once
#include "Participant.h"
#include <vector>
using namespace std;

class ONG {
private:
	vector<Participant*> participanti;
public:
	ONG(vector<Participant*> p) :participanti{ p } {};

	void add(Participant* p) {
		participanti.push_back(p);
	}

	vector<Participant*> getAll(bool x) {
		vector<Participant*> returnare;
		for (auto p : participanti) {
			if (p->eVoluntar() == x)
				returnare.push_back(p);
		}
		return returnare;
	}
};
