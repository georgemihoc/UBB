#pragma once
#include "Participant.h"

class Personal :public Participant {
private:
	string nume;
public:
	Personal(string nume) :Participant(), nume{ nume }{};
	~Personal() {};

	void tipareste() override {
		cout << nume;
	}
};
