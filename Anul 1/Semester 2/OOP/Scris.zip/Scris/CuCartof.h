#pragma once
#include "Mancare.h"
class CuCartof:public Mancare
{
	Mancare* mancare;
public:
	CuCartof(Mancare* m) :Mancare(m->getPret()), mancare{ m }{};
	~CuCartof() {
		cout << "Distruge cu cartof";
	};
	string descriere() override {
		return mancare->descriere().append(" cu cartof");
	}

	int getPret() const override {
		return mancare->getPret() + 3;
	}
};

