#pragma once
#include "Personal.h"
class Director : public Personal {
public:
	Director(string nume) :Personal(nume) {};
	~Director() {};

	void tipareste() override {
		Personal::tipareste(); 
		cout << " director";
	}
};