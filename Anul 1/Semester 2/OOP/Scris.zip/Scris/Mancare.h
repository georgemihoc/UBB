#pragma once
#include <iostream>
#include <string>
using namespace std;
class Mancare
{
private:
	int pret;
public:
	Mancare(int p) :pret{ p } {};

	~Mancare() { cout << "Se distruge mancarea";	};

	virtual int getPret() const {
		return pret;
	}

	virtual string descriere() = 0;
};

