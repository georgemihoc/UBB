#pragma once
#include "Mancare.h"
class CuSos :public Mancare
{
	Mancare* mancare;
public:
	CuSos(Mancare* m) :Mancare{ m->getPret() }, mancare { m } {};
	~CuSos() {
		cout << "Distruge cu sos";
	};
	string descriere() override {
		return mancare->descriere().append(" cu sos");
	}

	int getPret() const override {
		return mancare->getPret() + 2;
	}
};

