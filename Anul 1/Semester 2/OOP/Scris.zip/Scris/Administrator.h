#pragma once
#include "Personal.h"
class Administrator : public Personal {
public:
	Administrator(string nume) :Personal(nume) {};
	~Administrator() {};

	void tipareste() override {
		Personal::tipareste();
		cout<< " Administrator";
	}
}; 
