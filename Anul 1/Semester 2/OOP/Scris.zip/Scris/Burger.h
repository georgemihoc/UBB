#pragma once
#include "Mancare.h"
class Burger:public Mancare
{
private:
	string nume;
public:
	Burger(int pret,string num) :Mancare(pret) {
		this->nume = num;
	};
	~Burger() { cout << "distruge"; };

	string descriere() override {
		return nume;
	}

};

