using namespace std;
#include <vector>
#include <algorithm>
#include <string>
#include <stack>
#include <iostream>
#include "Mancare.h"
#include "Burger.h"
#include "CuCartof.h"
#include "CuSos.h"
#include <assert.h>
#include "Participant.h"
#include "ONG.h"
#include "Administrator.h"
#include "Director.h"
#include "Angajat.h"
#include "Personal.h"
#include <functional>
//P2b)
void f(bool b) {
	cout << "1";
	if (b) throw exception("Error");
	cout << "3";
}



//P2a)
class A {
public:
	virtual void print() = 0;
};

class B : public A {
public:
	virtual void print() {
		std::cout << "printB";
	}
};

class C : public B {
public: 

	virtual void print(){
		std::cout << "printC";
	}
};


/*	P1)
	Functia de inversare a unui vector de stringuri
	Input: l - vector<string> 
	Output: vector<string> - inversul lui l
			arunca o exceptie daca vectorul dat ca parametru este gol
*/
vector<string> g(vector<string> l) {
	if (l.size() == 0) throw exception("illegal argument");
	stack<string> st;
	for (auto&s : l) {
		st.push(s);
	}
	vector<string> r;
	while (!st.empty()) {
		r.push_back(st.top());
		st.pop();
	}
	return r;
}

vector<Mancare*> mancaruri() {
	Mancare* zinger = new Burger{ 10,"ZINGER" };
	Mancare* bigmac = new Burger{ 5,"BIG MAC" };
	Mancare* bigmacCS = new CuCartof{new CuSos{bigmac} };
	Mancare* zingerCartof = new CuCartof{ zinger };
	Mancare* zingerSos = new CuSos{ zinger };
	vector<Mancare*> meniu{ bigmac,bigmacCS,zingerCartof,zingerSos };
	return meniu;


}

int main() {
	/*
	vector<string> l;
	try {
		vector<string> err = g(l);
	}
	catch (exception& ex) {
		assert(true);
	}
	l.push_back("ana");
	l.push_back("are");
	l.push_back("mere");
	vector<string> merge = g(l);
	assert(merge.at(0) == "mere");
	assert(merge.at(2) == "ana");
	*/
	/*
	
	vector<A> v;
	B b;
	C c;
	
	v.push_back(b); // primesc eroare aici -> nu pot instantia o clasa abstracta
	v.push_back(c);
	for (auto& e : v) { 
		e.print(); }
	cout << endl;
	*/

	
	try {
		f(false);
		f(true);
		f(false);
	}
	catch (exception& ex) {
		cout << "4";
	}

	


	/*
	vector<Mancare*> meniu = mancaruri();
	sort(meniu.begin(), meniu.end(), []( Mancare* m1, Mancare* m2) {
		return m1->getPret() > m2->getPret();
	});
	for (auto& a : meniu) {
		cout << a->descriere() << " " << a->getPret();
		cout << endl;
	}

	Participant* adminVoluntar = new Administrator("AVoluntar");
	Participant* adminAngajat = new Angajat(new Administrator("AAngajat"));
	Participant* directorVoluntar = new Director("DVoluntar");
	Participant* directorAngajat = new Angajat(new Director("DAngajat"));
	vector<Participant*> p{ adminVoluntar,adminAngajat,directorVoluntar,directorAngajat };
	ONG ong{ p };
	cout << "VOLUNTARII : "<<endl;
	for (auto a : ong.getAll(true)) {
		a->tipareste();
		cout << endl;
	}
	cout << endl;
	cout << "ANGAJATI : "<<endl;
	for (auto a : ong.getAll(false)) {
		a->tipareste();
		cout << endl;
	}

	vector<int> intregi(2);
	intregi.push_back(1);
	intregi.push_back(2);
	intregi.push_back(3);
	intregi.push_back(3);
	*/
	int x;
	cin >> x;
	return 0;
}

