#pragma once
#include "Participant.h"

class Angajat : public Participant
{
private:
	Participant* part;
public:
	Angajat(Participant* p) :Participant(), part{ p }{};
	~Angajat() {};

	bool eVoluntar() override {
		return false;
	}

	void tipareste() override {
		part->tipareste(); 
		cout<< " " << "angajat";
	}
};