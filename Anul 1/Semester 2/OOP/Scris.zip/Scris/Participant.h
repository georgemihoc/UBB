#pragma once
#include <string>
#include <iostream>
using namespace std;

class Participant {
public:
	Participant() {};
	~Participant() {};

	virtual void tipareste() = 0;

	virtual bool eVoluntar() {
		return true;
	}
};