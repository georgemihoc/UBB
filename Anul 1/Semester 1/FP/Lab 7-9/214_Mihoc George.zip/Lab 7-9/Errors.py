class RepoError(Exception):
    pass

class ValidError(Exception):
    pass

