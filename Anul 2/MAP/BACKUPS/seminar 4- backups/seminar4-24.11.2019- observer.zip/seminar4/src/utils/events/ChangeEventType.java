package utils.events;

public enum ChangeEventType {
    ADD,UPDATE,DELETE,ADDNOTA;
}
