//package service;
//
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import utils.events.NotaChangeEvent;
//import utils.observer.Observer;
//import validators.Nota;
//import validators.NotaDto;
//import javafx.fxml.FXML;
//import javafx.scene.control.*;
//import javafx.scene.control.cell.PropertyValueFactory;
//import java.util.List;
//import java.util.stream.Collectors;
//import java.util.stream.StreamSupport;
//
//public class NotaController  implements Observer<NotaChangeEvent> {
//    Service service;
//    ServiceNota serviceNota;
//    ObservableList<NotaDto> modelNote = FXCollections.observableArrayList();
//
//    @FXML
//    TableView<NotaDto> tableViewNote;
//    @FXML
//    TableColumn<NotaDto,String> tableColumnStudent;
//    @FXML
//    TableColumn<NotaDto,String> tableColumnTema;
//    @FXML
//    TableColumn<NotaDto,String> tableColumnNota;
//    @FXML
//    TableColumn<NotaDto,String> tableColumnSaptamana;
//    public void setNotaService(ServiceNota serviceNota) {
//        this.serviceNota = serviceNota;
//        serviceNota.addObserver(this);
//        initModelNote();
//    }
//    @FXML
//    public void initialize() {
//        tableColumnStudent.setCellValueFactory(new PropertyValueFactory<>("studentName"));
//        tableColumnTema.setCellValueFactory(new PropertyValueFactory<>("temaName"));
//        tableColumnNota.setCellValueFactory(new PropertyValueFactory<>("nota"));
//        tableColumnSaptamana.setCellValueFactory(new PropertyValueFactory<>("date"));
//        tableViewNote.setItems(modelNote);
//    }
//    private void initModelNote() {
//        Iterable<Nota> note = serviceNota.findAllNota();
//        List<NotaDto> noteList = StreamSupport.stream(note.spliterator(), false)
//                .map(nota->new NotaDto(service.findStudent(nota.getIdStudent()).getNume(),service.findTema(nota.getIdTema()).getDescriere(),nota.getDate(),nota.getNota()))
//                .collect(Collectors.toList());
//        modelNote.setAll(noteList);
//    }
//    @Override
//    public void update(NotaChangeEvent notaChangeEvent) {
//        initModelNote();
//    }
//}
