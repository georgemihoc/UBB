package anUniversitar;

public class Saptamana {
    int id;
    public boolean vacanta;

    public Saptamana(int id) {
        this.id = id;
    }

    public void setVacanta(boolean b) {
        this.vacanta = b;
    }
}
