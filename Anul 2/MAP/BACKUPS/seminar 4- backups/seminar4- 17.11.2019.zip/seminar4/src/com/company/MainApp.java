package com.company;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import repository.InMemoryRepository;
import repository.NotaRepository;
import repository.StudentFileRepository;
import repository.TemaFileRepository;
import service.Service;
import service.StudentController;
import validators.*;


import javafx.scene.control.Button;
import javafx.scene.control.TextField;


import java.awt.*;
import java.io.IOException;

public class MainApp extends Application {

    Validator validator ;
    StudentFileRepository repository;

    Validator validator1;
    TemaFileRepository repository1;


    Validator validator2 ;
    InMemoryRepository<Long, Tema> repository2 ;

    Service service;
//
//    public MainApp(Service service) {
//        this.service = service;
//    }

    public void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        Validator validator = new ValidatorStudent();
        StudentFileRepository repository = new StudentFileRepository(validator);//,"/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/students.csv");

        Validator validator1 = new ValidatorTema();
        TemaFileRepository repository1 = new TemaFileRepository(validator1);//,"/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/tema.csv");


        Validator validator2 = new ValidatorNota();
        InMemoryRepository<Long, Tema> repository2 = new NotaRepository(validator2);

        this.service = new Service(validator,repository,validator1,repository1,validator2,repository2);

        //System.out.println(service.findStudent(1l));

        init1(primaryStage);
        primaryStage.setWidth(800);
        primaryStage.show();
    }

    private void init1(Stage primaryStage) throws IOException {
        FXMLLoader messageLoader = new FXMLLoader();
        messageLoader.setLocation(getClass().getResource("/com/company/StudentView.fxml"));

        AnchorPane studentLayout = messageLoader.load();
        primaryStage.setScene(new Scene(studentLayout));

        StudentController studentController = messageLoader.getController();
        studentController.setStudentService(service);

        //primaryStage.show();
    }
}