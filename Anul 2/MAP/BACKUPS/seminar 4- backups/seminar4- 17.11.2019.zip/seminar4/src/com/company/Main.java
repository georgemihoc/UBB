package com.company;

import repository.InMemoryRepository;
import repository.NotaRepository;
import repository.StudentFileRepository;
import repository.TemaFileRepository;
import service.Service;
import validators.*;

public class Main {
    public static void main(String[] args)  {
//        Validator validator = new ValidatorStudent();
//        StudentFileRepository repository = new StudentFileRepository(validator);//,"/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/students.csv");
//
//        Validator validator1 = new ValidatorTema();
//        TemaFileRepository repository1 = new TemaFileRepository(validator1);//,"/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/tema.csv");
//
//
//        Validator validator2 = new ValidatorNota();
//        InMemoryRepository<Long, Tema> repository2 = new NotaRepository(validator2);
//
//        Service service = new Service(validator,repository,validator1,repository1,validator2,repository2);

//        CONSOLE RUN
//        UI ui = new UI(service);
//        ui.run(args);

        ///GUI
          MainApp mainApp = new MainApp();
          mainApp.main(args);

    }
}