package repository;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import validators.Student;
import validators.Tema;
import validators.ValidationException;
import validators.Validator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.stream.Stream;

public class StudentFileRepository extends InMemoryRepository<Long, Student> {

    private void loadDataXML(){
        try {

            File fXmlFile = new File("/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/data.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);

            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("student");


            for (int temp = 0; temp < nList.getLength(); temp++) {

                Node nNode = nList.item(temp);


                if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element eElement = (Element) nNode;

                    String nume =  eElement.getElementsByTagName("nume").item(0).getTextContent();
                    int grupa = Integer.parseInt(eElement.getElementsByTagName("grupa").item(0).getTextContent());
                    String email =  eElement.getElementsByTagName("email").item(0).getTextContent();
                    String cadruDidactic =  eElement.getElementsByTagName("cadru_didactic").item(0).getTextContent();
                    Student student= new Student(nume,grupa,email,cadruDidactic);
                    student.setId(findID());
                    super.save(student);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void rewriteFileXML(){
        String xmlFilePath = "/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/data.xml";

        try {

            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();

            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();

            Document document = documentBuilder.newDocument();

            // root element
            Element root = document.createElement("class");
            document.appendChild(root);
            for (Student s:findAll()) {

                // employee element
                Element employee = document.createElement("student");

                root.appendChild(employee);

                // firstname element
                Element firstName = document.createElement("nume");
                firstName.appendChild(document.createTextNode(s.getNume()));
                employee.appendChild(firstName);

                // lastname element
                Element lastname = document.createElement("grupa");
                lastname.appendChild(document.createTextNode(String.valueOf(s.getGrupa())));
                employee.appendChild(lastname);

                // email element
                Element email = document.createElement("email");
                email.appendChild(document.createTextNode(s.getEmail()));
                employee.appendChild(email);

                // department elements
                Element department = document.createElement("cadru_didactic");
                department.appendChild(document.createTextNode(s.getCadruDidactic()));
                employee.appendChild(department);
            }

            // create the xml file
            //transform the DOM Object to an XML File
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(new File(xmlFilePath));


            transformer.transform(domSource, streamResult);


        } catch (ParserConfigurationException | TransformerException pce) {
            pce.printStackTrace();
        }
    }
    @Override
    public Student save(Student entity) throws ValidationException {
        Student s = super.save(entity);
//        if(s==null)
//            rewriteFileXML();
            //writeToFile(entity);
        return s;
    }

    @Override
    public Student delete(Long id) {
        Student s =super.delete(id);
//        rewriteFileXML();
        return s;
    }

    @Override
    public Student update(Student entity) {
        Student s=  super.update(entity);
//        rewriteFileXML();
        return s;
    }

    public StudentFileRepository(Validator<Student> validator){//, String fileN) {
        super(validator);
        //loadDataXML();
    }
}