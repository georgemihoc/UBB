package repository;


import validators.*;
import validators.Nota;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class NotaFileRepository extends InMemoryRepository<Pair, Nota> {
    String fileName;

    @Override
    public Nota save(Nota entity) throws ValidationException {
        Nota s = super.save(entity);
//        if(s==null)
//            writeToFile(entity);
        return s;
    }

    @Override
    public Nota delete(Pair pair) {
        Nota s =super.delete(pair);
//        rewriteFile();
        return s;
    }

    @Override
    public Nota update(Nota entity) {
        Nota s=  super.update(entity);
//        rewriteFile();
        return s;
    }

    public NotaFileRepository(Validator<Nota> validator, String fileN) {
        super(validator);
        //loadData();
    }
}