package com.company;

import repository.*;
import service.Service;
import validators.*;

public class Main {
    private static void runConsole(String[] args){
        Validator validator = new ValidatorStudent();
        StudentFileRepository repository = new StudentFileRepository(validator);

        Validator validator1 = new ValidatorTema();
        TemaFileRepository repository1 = new TemaFileRepository(validator1);


        Validator validator2 = new ValidatorNota();
        NotaFileRepository repository2 = new NotaFileRepository(validator2);

        Service service = new Service(validator,repository,validator1,repository1,validator2,repository2);
        service.studentFileGeneral();

//        CONSOLE RUN
        UI ui = new UI(service);
        ui.run(args);
    }
    private static void runGUI(String[] args){
        ///GUI
          MainApp mainApp = new MainApp();
          mainApp.main(args);
    }
    public static void main(String[] args)  {
//        runConsole(args);
        runGUI(args);
    }
}