package service;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import validators.Student;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class StudentController  {
    Service service;
    ObservableList<Student> model = FXCollections.observableArrayList();


    @FXML
    TableView<Student> tableView;
    @FXML
    TableColumn<Student,String> tableColumnNume;
    @FXML
    TableColumn<Student,String> tableColumnGrupa;
    @FXML
    TableColumn<Student,String> tableColumnEmail;
    @FXML
    TableColumn<Student,String> tableColumnCadruDidactic;

    public void setStudentService(Service service) {
        this.service = service;
        //service.addObserver(this);
        initModel();
    }

    @FXML
    public void initialize() {
        tableColumnNume.setCellValueFactory(new PropertyValueFactory<Student, String>("nume"));
        tableColumnGrupa.setCellValueFactory(new PropertyValueFactory<Student, String>("grupa"));
        tableColumnEmail.setCellValueFactory(new PropertyValueFactory<Student, String>("email"));
        tableColumnCadruDidactic.setCellValueFactory(new PropertyValueFactory<Student, String>("cadruDidactic"));
        tableView.setItems(model);
    }

    private void initModel() {
        Iterable<Student> students = service.findAllStudents();
//        System.out.println(students);
        List<Student> studentList = StreamSupport.stream(students.spliterator(), false)
                .collect(Collectors.toList());
        model.setAll(studentList);
    }

    public void update() {
        initModel();
    }

    public void handleDeleteStudent(ActionEvent actionEvent) {
        Student selected = (Student) tableView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Student deleted = service.deleteStudent(selected.getId());
            if (null != deleted)
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Delete", "Studentul a fost sters cu succes!");
        } else MessageAlert.showErrorMessage(null, "Nu ati selectat nici un student!");
        update();
    }

    public void showStudentEditDialog(Student student) {
        try {
            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/com/company/EditStudentView.fxml"));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Edit Message");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            EditStudentController editStudentController = loader.getController();
            editStudentController.setService(service, dialogStage, student);

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
        //update();
    }

    public void handleAddStudent(ActionEvent ev) {
        showStudentEditDialog(null);
        update();

    }
    @FXML
    public void handleUpdateStudent(ActionEvent ev) {
        Student selected = tableView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            showStudentEditDialog(selected);
        }
        else
            MessageAlert.showErrorMessage(null, "NU ati selectat nici un student");
    }

    public void handleRefresh(ActionEvent actionEvent) {
        update();
    }

}
