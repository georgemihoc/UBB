package com.company;

import configuration.ApplicationContext;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import repository.*;
import service.Service;
import service.ServiceNota;
import service.MainViewController;
import validators.*;


import java.io.IOException;


public class MainApp extends Application {

    Validator validator ;
    StudentFileRepository repository;

    Validator validator1;
    TemaFileRepository repository1;


    Validator validator2 ;
    InMemoryRepository<Long, Tema> repository2 ;

    Service service;
    ServiceNota serviceNota;
//
//    public MainApp(Service service) {
//        this.service = service;
//    }

    public void main(String[] args) {
        launch(args);
    }


    @Override
    public void start(Stage primaryStage) throws IOException {
        String fileStudents = ApplicationContext.getPROPERTIES().getProperty("data.students");
        String fileTeme = ApplicationContext.getPROPERTIES().getProperty("data.teme");
        String fileNote = ApplicationContext.getPROPERTIES().getProperty("data.note");

        Validator validator = new ValidatorStudent();
        StudentFileRepository repository = new StudentFileRepository(validator,fileStudents);

        Validator validator1 = new ValidatorTema();
        TemaFileRepository repository1 = new TemaFileRepository(validator1,fileTeme);


        Validator validator2 = new ValidatorNota();
        NotaFileRepository repository2 = new NotaFileRepository(validator2,fileNote);

        this.service = new Service(validator,repository,validator1,repository1);
        this.serviceNota = new ServiceNota(repository2,validator2);

        service.fileDelete();
        service.studentFileGeneral();

        init1(primaryStage);
        primaryStage.setWidth(800);
        primaryStage.show();
    }

    private void init1(Stage primaryStage) throws IOException {
        FXMLLoader messageLoader = new FXMLLoader();
        String mainView = ApplicationContext.getPROPERTIES().getProperty("view.main");
        messageLoader.setLocation(getClass().getResource(mainView));

        AnchorPane studentLayout = messageLoader.load();
        primaryStage.setScene(new Scene(studentLayout));
        primaryStage.setHeight(700);
        primaryStage.setWidth(1000);

        MainViewController mainViewController = messageLoader.getController();
        mainViewController.setStudentService(service,serviceNota);

        //primaryStage.show();
    }
}