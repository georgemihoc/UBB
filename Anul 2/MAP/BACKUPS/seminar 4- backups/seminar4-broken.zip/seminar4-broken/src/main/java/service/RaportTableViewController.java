package service;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import utils.events.ChangeEvent;
import utils.observer.Observer;
import validators.*;
import java.util.ArrayList;
import java.util.List;


public class RaportTableViewController implements Observer<ChangeEvent> {
    @FXML
    TableView<Raport1> tableViewRaport;
    @FXML
    TableColumn<Raport1,String> tableColumnStudent;
    @FXML
    TableColumn<Raport1,String> tableColumnNota;
    int raport;

    private Service service;
    private ServiceNota serviceNota;
    ObservableList<Raport1> modelRaport = FXCollections.observableArrayList();
    @FXML
    public void initialize() {


        tableColumnStudent.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        tableColumnNota.setCellValueFactory(new PropertyValueFactory<>("nota"));
        tableViewRaport.setItems(modelRaport);

    }

    public void setService(Service service, ServiceNota serviceNota, int raport) {
        this.service = service;
        this.serviceNota = serviceNota;
        service.addObserver(this);
        serviceNota.addObserver(this);
        if(raport != 4)
            initModel(raport);
        else
            initModel2(raport);

    }

    private void initModel(int raport) {
        this.raport = raport;
        Iterable<Nota> note = ServiceNota.findAllNota();
        Iterable<Student> students = Service.findAllStudents();
        Iterable<Tema> teme = Service.findAllTema();
        List<Raport1> medie = new ArrayList<>();
        int nrSaptamani=0;
        for (Tema t:
             teme) {
            nrSaptamani += (t.getDeadlineWeek()-t.getStartWeek());
        }
        for (Student s:
             students) {
            float suma= 0;
            for (Nota n:
                 note) {
                if(s.getId().equals(n.getIdStudent()))
                    suma += n.getNota()*(service.findTema(n.getIdTema()).getDeadlineWeek()-service.findTema(n.getIdTema()).getStartWeek());
            }
            suma /= nrSaptamani;
            if( suma>4 || raport!=3 )
                medie.add(new Raport1(s.getNume(),suma));
        }
        modelRaport.setAll(medie);

    }
    private void initModel2(int raport){
        this.raport = raport;
        Iterable<Nota> note = ServiceNota.findAllNota();
        Iterable<Student> students = Service.findAllStudents();
        Iterable<Tema> teme = Service.findAllTema();
        List<Raport1> raport4 = new ArrayList<>();
        int nrSaptamani=0;
        for (Tema t:
                teme) {
            nrSaptamani += (t.getDeadlineWeek()-t.getStartWeek());
        }
        for (Student s:
                students) {
            boolean ok = true;
            float suma= 0;
            for (Nota n :
                    note) {
                if(s.getId().equals(n.getIdStudent())) {
                    suma += n.getNota() * (service.findTema(n.getIdTema()).getDeadlineWeek() - service.findTema(n.getIdTema()).getStartWeek());
                    if (n.getDate() > service.findTema(n.getIdTema()).getDeadlineWeek())
                        ok = false;
                }
            }
            suma /= nrSaptamani;
            if(ok && suma!=0){
                raport4.add(new Raport1(s.getNume(),suma));
            }
        }
        modelRaport.setAll(raport4);
    }

    @Override
    public void update(ChangeEvent changeEvent) {
        initModel(this.raport);
    }
}
