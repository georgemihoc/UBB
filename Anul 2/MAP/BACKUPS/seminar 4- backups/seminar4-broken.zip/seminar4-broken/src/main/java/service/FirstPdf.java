package service;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;


public class FirstPdf {


    public static void main(String[] args) {
        File file = new File("/Users/george/Desktop/1.pdf");


        PdfWriter writer = null;
        try {
            writer = new PdfWriter(file);
            System.out.println(file.getName());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);
        document.add(new Paragraph("sal ba"));
        document.close();
    }
}
