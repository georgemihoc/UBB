package repository;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import validators.*;
import validators.Tema;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class TemaFileRepository extends InMemoryRepository<Long, Tema> {
    String fileName;

    @Override
    public Tema save(Tema entity) throws ValidationException {
        Tema s = super.save(entity);
        //if(s==null)
         //   writeToFile(entity);
        return s;
    }

    @Override
    public Tema delete(Long id) {
        Tema s =super.delete(id);
        //rewriteFile();
        return s;
    }

    @Override
    public Tema update(Tema entity) {
        Tema s=  super.update(entity);
        //rewriteFile();
        return s;
    }

    public TemaFileRepository(Validator<Tema> validator, String fileN) {
        super(validator);
        fileName=fileN;
        //loadData();
    }
}