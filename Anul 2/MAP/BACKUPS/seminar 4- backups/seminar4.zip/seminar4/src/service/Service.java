package service;

import anUniversitar.AnUniversitar;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import repository.InMemoryRepository;
import repository.StudentFileRepository;
import repository.TemaFileRepository;
import validators.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class Service {
    private StudentFileRepository repositoryStudent;
    private Validator validatorStudent;
    private TemaFileRepository repositoryTema;
    private Validator validatorTema;
    private InMemoryRepository repositoryNota;
    private Validator validatorNota;

    public Service(Validator validatorStudent, StudentFileRepository repositoryStudent,
                   Validator validatorTema, TemaFileRepository repositoryTema,Validator validatorNota,
                   InMemoryRepository repositoryNota) {
        this.validatorStudent = validatorStudent;
        this.repositoryStudent = repositoryStudent;
        this.validatorTema = validatorTema;
        this.repositoryTema = repositoryTema;
        this.validatorNota= validatorNota;
        this.repositoryNota= repositoryNota;
        loadDataXML();
    }
    /**
     * Functie de incarcare date din fisierul date.xml
     * input-
     * preconditii-
     * output-
     * postconditii-
     */
    public void loadDataXML(){
        try {

            File fXmlFile = new File("/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/data.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);

            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("student");


            for (int temp = 0; temp < nList.getLength(); temp++) {

                Node nNode = nList.item(temp);


                if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element eElement = (Element) nNode;

                    String nume =  eElement.getElementsByTagName("nume").item(0).getTextContent();
                    int grupa = Integer.parseInt(eElement.getElementsByTagName("grupa").item(0).getTextContent());
                    String email =  eElement.getElementsByTagName("email").item(0).getTextContent();
                    String cadruDidactic =  eElement.getElementsByTagName("cadru_didactic").item(0).getTextContent();
//                    Student student= new Student(nume,grupa,email,cadruDidactic);
//                    student.setId(repositoryStudent.findID());
//                    repositoryStudent.save(student);
                    addStudent(nume,grupa,email,cadruDidactic);
                }
            }
            fileDelete();

            NodeList nList1 = doc.getElementsByTagName("tema");
            for (int temp = 0; temp < nList1.getLength(); temp++) {

                Node nNode = nList1.item(temp);


                if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element eElement = (Element) nNode;

                    String descriere =  eElement.getElementsByTagName("descriere").item(0).getTextContent();
                    int startweek = Integer.parseInt(eElement.getElementsByTagName("startweek").item(0).getTextContent());
                    int deadlineweek = Integer.parseInt(eElement.getElementsByTagName("deadlineweek").item(0).getTextContent());
//                    Tema tema= new Tema(descriere,startweek,deadlineweek);
//                    tema.setId(repositoryTema.findID());
//                    repositoryTema.save(tema);
                    addTema(descriere,startweek,deadlineweek);
                }
            }
            NodeList nList2 = doc.getElementsByTagName("nota");
            for (int temp = 0; temp < nList2.getLength(); temp++) {

                Node nNode = nList2.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element eElement = (Element) nNode;
                    try {

                        long idStudent = Long.parseLong(eElement.getElementsByTagName("idStudent").item(0).getTextContent());
                        long idTema = Long.parseLong(eElement.getElementsByTagName("idTema").item(0).getTextContent());
                        float nota = Float.parseFloat(eElement.getElementsByTagName("nota").item(0).getTextContent());
                        int week = Integer.parseInt(eElement.getElementsByTagName("week").item(0).getTextContent());
                        String feedback = eElement.getElementsByTagName("feedback").item(0).getTextContent();
//                    Nota nota1= new Nota(idStudent,idTema,week,nota,feedback);
//                    nota1.setId(repositoryNota.findID());
//                    repositoryNota.save(nota1);
                        addNota(idStudent, idTema, nota, week, feedback);
                    }catch (Exception ignore){

                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * Functie de scriere a fisierului xml cu datele din repository-urile Nota, Student, Tema
     * input-
     * preconditii-
     * output-
     * postconditii-
     */
    private void rewriteFileXML(){
        String xmlFilePath = "/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/data.xml";

        try {
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();

            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();

            Document document = documentBuilder.newDocument();

            // root element
            Element root = document.createElement("class");
            document.appendChild(root);
            for (Student s:findAllStudents()) {

                // employee element
                Element student = document.createElement("student");

                root.appendChild(student);

                // firstname element
                Element name = document.createElement("nume");
                name.appendChild(document.createTextNode(s.getNume()));
                student.appendChild(name);

                // lastname element
                Element grupa = document.createElement("grupa");
                grupa.appendChild(document.createTextNode(String.valueOf(s.getGrupa())));
                student.appendChild(grupa);

                // email element
                Element email = document.createElement("email");
                email.appendChild(document.createTextNode(s.getEmail()));
                student.appendChild(email);

                // department elements
                Element cadruDidactic = document.createElement("cadru_didactic");
                cadruDidactic.appendChild(document.createTextNode(s.getCadruDidactic()));
                student.appendChild(cadruDidactic);
            }
            for (Tema t:findAllTema()) {

                // employee element
                Element tema = document.createElement("tema");

                root.appendChild(tema);

                Element descriere = document.createElement("descriere");
                descriere.appendChild(document.createTextNode(t.getDescriere()));
                tema.appendChild(descriere);

                Element startweek = document.createElement("startweek");
                startweek.appendChild(document.createTextNode(String.valueOf(t.getStartWeek())));
                tema.appendChild(startweek);

                Element deadlineweek = document.createElement("deadlineweek");
                deadlineweek.appendChild(document.createTextNode(String.valueOf(t.getDeadlineWeek())));
                tema.appendChild(deadlineweek);

            }
            for (Nota n:findAllNota()) {

                // employee element
                Element nota = document.createElement("nota");

                root.appendChild(nota);

                Element idStudent = document.createElement("idStudent");
                idStudent.appendChild(document.createTextNode(String.valueOf(n.getIdStudent())));
                nota.appendChild(idStudent);

                Element idTema = document.createElement("idTema");
                idTema.appendChild(document.createTextNode(String.valueOf(n.getIdTema())));
                nota.appendChild(idTema);

                Element nota1 = document.createElement("nota");
                nota1.appendChild(document.createTextNode(String.valueOf(n.getNota())));
                nota.appendChild(nota1);

                Element week = document.createElement("week");
                week.appendChild(document.createTextNode(String.valueOf(n.getDate())));
                nota.appendChild(week);

                Element feedback = document.createElement("feedback");
                feedback.appendChild(document.createTextNode(String.valueOf(n.getFeedback())));
                nota.appendChild(feedback);

            }

            // create the xml file
            //transform the DOM Object to an XML File
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(new File(xmlFilePath));


            transformer.transform(domSource, streamResult);


        } catch (ParserConfigurationException | TransformerException pce) {
            pce.printStackTrace();
        }
    }


    /**
     * Functie de scriere note in fisierul note.csv
     * input-
     * preconditii-
     * output-
     * postconditii-
     */
    public void writeNotaFile()
    {
        PrintWriter writer = null;
        try {
            writer = new PrintWriter("/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/note.csv");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        writer.print("");
        writer.close();

        try(FileWriter fw = new FileWriter("/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/note.csv", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            for (Nota n:this.findAllNota()) {
                out.print(n.getIdStudent());
                out.print(";");
                //
                out.print(n.getIdTema());
                out.print(";");
                //
                out.print(n.getNota());
                out.print(";");
                //
                out.print(n.getDate());
                out.print(";");
                //
                out.println(n.getFeedback());
            }

        } catch (IOException ignored) {
        }
    }
    /**
     * Functie de add student
     * input-  nume, grupa, email, cadruDidactic
     * preconditii- nume-String ; grupa-int ; email- String ; cadruDidactic- String
     * output-
     * postconditii-
     */
    public void addStudent(String nume, int grupa, String email, String cadruDidactic) {
        Student s = new Student(nume, grupa, email, cadruDidactic);
        s.setId(repositoryStudent.findID());

        try {
            repositoryStudent.save(s);
            rewriteFileXML();
            //writeStudentFile(s);
        } catch (ValidationException ex) {
            //System.out.println(ex.getMessage());
        } catch (IllegalArgumentException il) {
            //System.out.println(il.getMessage());
        } catch (Exception ex) {
            //System.out.println("Student invalid");
        }
    }
    /**
     * Functie de delete student
     * input- id
     * preconditii- id- long ;
     * output-
     * postconditii-
     */
    public void deleteStudent(long id){
        if(repositoryStudent.delete((long)id)==null)
            System.out.println("Nu exista acest id");
        else {
            System.out.println("Student sters");
            rewriteFileXML();
        }
    }
    /**
     * Functie de update student
     * input- id, nume, grupa, email, cadruDidactic
     * preconditii- id- long ; nume-String ; grupa-int ; email- String ; cadruDidactic- String
     * output-
     * postconditii-
     */
    public void updateStudent(long id,String nume, int grupa, String email, String cadruDidactic){
        Student s = new Student(nume,grupa,email,cadruDidactic);
        s.setId(id);
        repositoryStudent.update(s);
        rewriteFileXML();
    }
    /**
     * Functie de adaugare unei Teme
     * input- descriere, currentWeek, deadlineWeek, feedback
     * preconditii- descriere- String ; currentWeek, deadlineWeek- int;
     * output-
     * postconditii-
     */
    public void addTema(String descriere, int currentWeek, int deadlineWeek) {
        AnUniversitar an = new AnUniversitar();
        int startWeek;
        List<String> lista = null;
        InputStream ins = null; // raw byte-stream
        Reader r = null; // cooked reader
        BufferedReader br = null; // buffered for readLine()
        int ok = 1;
        try {
            String s;
            ins = new FileInputStream("/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/anUniversitar/StructuraAn.txt");
            r = new InputStreamReader(ins, "UTF-8"); // leave charset out for default
            br = new BufferedReader(r);
            while ((s = br.readLine()) != null) {
                //System.out.println(s);
                if(s.equals(currentWeek))
                    ok = 1;

            }
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage()); // handle exception
        }

//        if (an.saptamani.get(currentWeek).vacanta) {
//            startWeek = an.getWeek(currentWeek);
//        } else {
//            startWeek = currentWeek;
//        }
        if (ok==1) {
            startWeek = an.getWeek(currentWeek);
        } else {
            startWeek = currentWeek;
        }

        Tema t = new Tema(descriere, startWeek, deadlineWeek);
        t.setId((long) repositoryTema.findID());
        repositoryTema.save(t);
        rewriteFileXML();
    }
    public void deleteTema(long id){
        if(repositoryTema.delete((long)id)==null)
            System.out.println("Nu exista acest id");
        else {
            System.out.println("Tema stearsa");
            rewriteFileXML();
        }
    }
    /**
     * Functie de update a unei teme
     * input- id, descriere, currentWeek, deadlineWeek
     * preconditii- id- long ; descriere- String ; currentWeek,deadlineWeek- int ;
     * output-
     * postconditii-
     */
    public void updateTema(long id, String descriere, int currentWeek, int deadlineWeek ){
        AnUniversitar an = new AnUniversitar();
        int startWeek;
        if(an.saptamani.get(currentWeek).vacanta)
        {
            startWeek = an.getWeek(currentWeek);
        }
        else {
            startWeek = currentWeek;
        }

        Tema t = new Tema(descriere, startWeek, deadlineWeek);
        t.setId(id);
        repositoryTema.update(t);
        rewriteFileXML();
    }
    /**
     * Functie de stergere a fisierelor personale
     * input-
     * preconditii-
     * output-
     * postconditii-
     */
    private void fileDelete(){

        for(Student s: this.findAllStudents()){
            String  path = "/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/";
            path = path + s.getNume() + ".txt";

            File file = new File(path);
            try {
                Files.deleteIfExists(Paths.get(path));
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }
    /**
     * Functie de creeare a fisierului personal cu nota
     * input- n, gradeWeek, deadlineWeek, feedback
     * preconditii- n- Nota ; gradeWeek, deadlineWeek- integer ; feedback- string;
     * output-
     * postconditii-
     */
    private void studentFile(Nota n, int gradeWeek, int deadlineWeek, String feedback){

        String  nume="",path = "/Users/george/Documents/UBB/Anul 2/MAP/seminar4/src/";

        for(Student s: this.findAllStudents()){
            if(s.getId() == n.getIdStudent())
                nume=s.getNume();
        }
        path = path + nume +".txt";
        FileWriter fw = null;
        try {
            fw = new FileWriter(path, true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);

        out.print("ID-ul temei:");
        out.println(n.getIdTema());
        //
        out.print("Nota:");
        out.println(n.getNota());
        //
        out.print("Predata in saptamana:");
        out.println(gradeWeek);
        //
        out.print("Deadline:");
        out.println(deadlineWeek);
        //
        out.print("Feedback:");
        out.println(feedback);
        out.println();
        out.close();
    }
    /**
     * Functie de adaugare a unei note
     * input- idStudent, idTemma, nota, gradeWeek, feedback
     * preconditii- idStudent,idTema- long ; nota- float ; gradeWeek- integer ; feedback- string;
     * output-
     * postconditii-
     */
    public void addNota(long idStudent,long idTema,float nota, int gradeWeek, String feedback ){
        String cadruDidactic="";
        int currentWeek =Integer.parseInt(new SimpleDateFormat("w").format(new java.util.Date()))-40+1;
        int deadlineWeek=currentWeek;
        for (Student s:this.findAllStudents()) {
            if(s.getId()== idStudent){
                cadruDidactic= s.getCadruDidactic();
            }
        }
        if(cadruDidactic.equals(""))
            throw new ValidationException("Student inexistent");
        boolean ok = false;
        for (Tema t:this.findAllTema()){
            if(t.getId()==idTema) {
                deadlineWeek = t.getDeadlineWeek();
                ok = true;
            }
        }
        if(!ok)
            throw new ValidationException("Tema inexistenta");

        if(gradeWeek>deadlineWeek){
            if(gradeWeek-deadlineWeek>2)
                nota = 0;
            else
                nota = nota - gradeWeek+deadlineWeek;
        }
        for (Nota n:this.findAllNota()){
            if(n.getIdStudent()==idStudent && n.getIdTema() == idTema)
                throw new ValidationException("Nota deja existenta");
        }
        try{
            Nota n = new Nota(idStudent,idTema,gradeWeek,nota,cadruDidactic,feedback);
            //n.setId(repositoryNota.findID());
            n.setId(new Pair(idStudent,idTema));
            studentFile(n,gradeWeek,deadlineWeek,feedback);
            repositoryNota.save(n);
            rewriteFileXML();
        }catch (Exception ex){
        }
    }

    /**
     * Functie care returneaza toti studentii unei grupe anume
     * input- students, grupa
     * preconditii- students (List<Student>), grupa (int)
     * output - collector
     * postconditii - List<student>
     */
    public static List<Student> report1(List<Student> students, int grupa) {
        Predicate<Student> p1 = x -> x.getGrupa() == grupa;
        //Predicate<Student> p = p1.and(p2);

        return students.stream()
                .filter(p1)
                .collect(Collectors.toList());
    }
    /**
     * Functie care returneaza toti studentii care au predat o anumita tema
     * input- note, id
     * preconditii- note (List<Nota>), id (long)
     * output - collector
     * postconditii - List<Nota>
     */
    public static List<Nota> report2(List<Nota> note, long id)
    {
        Predicate<Nota> p1 = x -> x.getIdTema() == id;
        return note.stream()
                .filter(p1)
                .collect(Collectors.toList());
    }
    /**
     * Functie care returneaza toti studentii care au predat o anumita tema unui profesor anume
     * input- note, id, cadruDidactic
     * preconditii- note (List<Nota>), id (long), cadruDidactic (String)
     * output - collector
     * postconditii - List<Nota>
     */
    public static List<Nota> report3(List<Nota> note, long id, String cadruDidactic)
    {
        Predicate<Nota> p1 = x -> x.getIdTema() == id;
        Predicate<Nota> p2 = x-> x.getProfesor().equals(cadruDidactic);
        Predicate<Nota> p = p1.and(p2);

        return note.stream()
                .filter(p)
                .collect(Collectors.toList());
    }
    /**
     * Functie care returneaza toate notele la o anumita tema dintr-o saptamana data
     * input- note, id, week
     * preconditii- note (List<Nota>), id (long), week (int)
     * output - collector
     * postconditii - List<Nota>
     */
    public static List<Nota> report4(List<Nota> note, long id, int week)
    {
        Predicate<Nota> p1 = x -> x.getIdTema() == id;
        Predicate<Nota> p2 = x-> x.getDate()== week;
        Predicate<Nota> p = p1.and(p2);

        return note.stream()
                .filter(p)
                .collect(Collectors.toList());
    }
    /**
     * Functie de findAll pt studenti
     * input-
     * preconditii-
     * output- repositoryStudent.findAll()
     * postconditii- repositoryStudent.findAll()- Iterable<Student>
     */
    public Iterable<Student> findAllStudents(){
        return repositoryStudent.findAll();
    }
    /**
     * Functie de find student
     * input-id
     * preconditii-id (long)
     * output- repositoryStudent.findOne()
     * postconditii- repositoryStudent.findAll()- Student
     */
    public Student findStudent(long id){
        return repositoryStudent.findOne(id);
    }
    /**
     * Functie de findAll pt teme
     * input-
     * preconditii-
     * output- repositoryTema.findAll()
     * postconditii- repositoryTema.findAll()- Iterable<Tema>
     */
    public Iterable<Tema> findAllTema(){
        return repositoryTema.findAll();
    }
    /**
     * Functie de findAll pt note
     * input-
     * preconditii-
     * output- repositoryNota.findAll()
     * postconditii- repositoryNota.findAll()- Iterable<Nota>
     */
    public Iterable<Nota> findAllNota(){
        return repositoryNota.findAll();
    }
}