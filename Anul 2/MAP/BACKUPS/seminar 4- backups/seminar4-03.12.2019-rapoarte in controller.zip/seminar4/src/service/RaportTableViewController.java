package service;

import configuration.ApplicationContext;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import utils.events.ChangeEvent;
import utils.observer.Observer;
import validators.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class RaportTableViewController implements Observer<ChangeEvent> {
    @FXML
    TableView<Raport1> tableViewRaport;
    @FXML
    TableColumn<Raport1,String> tableColumnStudent;
    @FXML
    TableColumn<Raport1,String> tableColumnNota;
    int raport;

    private Service service;
    private ServiceNota serviceNota;
    ObservableList<Raport1> modelRaport = FXCollections.observableArrayList();
    @FXML
    public void initialize() {

        tableColumnStudent.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        tableColumnNota.setCellValueFactory(new PropertyValueFactory<>("nota"));
        tableViewRaport.setItems(modelRaport);

    }

    public void setService(Service service, ServiceNota serviceNota, int raport) {
        this.service = service;
        this.serviceNota = serviceNota;
        service.addObserver(this);
        serviceNota.addObserver(this);
        if(raport != 4) {
            try {
                initModel(raport);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else {
            try {
                initModel2(raport);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private void initModel(int raport) throws IOException {
        PDDocument document = new PDDocument();
        PDPage page = new PDPage();
        document.addPage(page);

        PDPageContentStream contentStream = new PDPageContentStream(document, page);
        contentStream.beginText();
        contentStream.setFont(PDType1Font.TIMES_ROMAN, 20);
        contentStream.setLeading(14.5f);
        contentStream.newLineAtOffset(25, 750);
        if(raport==1)
            contentStream.showText("Medii Studenti");
        else if(raport == 3)
            contentStream.showText("Studentii care pot intra in examen");
        contentStream.newLine();
        contentStream.newLine();
        contentStream.setFont(PDType1Font.TIMES_ROMAN, 12);




        this.raport = raport;
        Iterable<Nota> note = ServiceNota.findAllNota();
        Iterable<Student> students = Service.findAllStudents();
        Iterable<Tema> teme = Service.findAllTema();
        List<Raport1> medie = new ArrayList<>();
        int nrSaptamani=0;
        for (Tema t:
             teme) {
            nrSaptamani += (t.getDeadlineWeek()-t.getStartWeek());
        }
        for (Student s:
             students) {
            float suma= 0;
            for (Nota n:
                 note) {
                if(s.getId().equals(n.getIdStudent()))
                    suma += n.getNota()*(service.findTema(n.getIdTema()).getDeadlineWeek()-service.findTema(n.getIdTema()).getStartWeek());
            }
            suma /= nrSaptamani;
            if( suma>4 || raport!=3 ) {
                medie.add(new Raport1(s.getNume(), suma));
                contentStream.showText("Student: " + s.getNume()+"     Medie: " + suma);
                contentStream.newLine();
            }
        }
        modelRaport.setAll(medie);

        contentStream.endText();
        contentStream.close();
        //Saving the document
        if(raport==1) {
            String path = ApplicationContext.getPROPERTIES().getProperty("raport.first");
            document.save(path);
        }
        else
        {
            String path = ApplicationContext.getPROPERTIES().getProperty("raport.third");
            document.save(path);
        }
        System.out.println("PDF created");
        //Closing the document
        document.close();

    }
    private void initModel2(int raport) throws IOException {
        PDDocument document = new PDDocument();
        PDPage page = new PDPage();
        document.addPage(page);

        PDPageContentStream contentStream = new PDPageContentStream(document, page);
        contentStream.beginText();
        contentStream.setFont(PDType1Font.TIMES_ROMAN, 20);
        contentStream.setLeading(14.5f);
        contentStream.newLineAtOffset(25, 750);
        contentStream.showText("Studentii care au predat toate temele la timp");
        contentStream.newLine();
        contentStream.newLine();
        contentStream.setFont(PDType1Font.TIMES_ROMAN, 12);



        this.raport = raport;
        Iterable<Nota> note = ServiceNota.findAllNota();
        Iterable<Student> students = Service.findAllStudents();
        Iterable<Tema> teme = Service.findAllTema();
        List<Raport1> raport4 = new ArrayList<>();
        int nrSaptamani=0;
        for (Tema t:
                teme) {
            nrSaptamani += (t.getDeadlineWeek()-t.getStartWeek());
        }
        for (Student s:
                students) {
            boolean ok = true;
            float suma= 0;
            for (Nota n :
                    note) {
                if(s.getId().equals(n.getIdStudent())) {
                    suma += n.getNota() * (service.findTema(n.getIdTema()).getDeadlineWeek() - service.findTema(n.getIdTema()).getStartWeek());
                    if (n.getDate() > service.findTema(n.getIdTema()).getDeadlineWeek())
                        ok = false;
                }
            }
            suma /= nrSaptamani;
            if(ok && suma!=0){
                raport4.add(new Raport1(s.getNume(),suma));
                contentStream.showText(s.getNume());
                contentStream.newLine();
            }
        }
        modelRaport.setAll(raport4);


        contentStream.endText();
        contentStream.close();
        //Saving the document
        String path = ApplicationContext.getPROPERTIES().getProperty("raport.fourth");
        document.save(path);
        System.out.println("PDF created");
        //Closing the document
        document.close();
    }

    @Override
    public void update(ChangeEvent changeEvent) {
        try {
            initModel(this.raport);
            if(raport == 4)
                initModel2(this.raport);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
