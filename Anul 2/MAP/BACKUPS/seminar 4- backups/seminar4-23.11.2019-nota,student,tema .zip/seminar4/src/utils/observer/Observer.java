package utils.observer;
import utils.events.Event;
import utils.events.NotaChangeEvent;

public interface Observer<E extends Event> {
    void update(E e);
}