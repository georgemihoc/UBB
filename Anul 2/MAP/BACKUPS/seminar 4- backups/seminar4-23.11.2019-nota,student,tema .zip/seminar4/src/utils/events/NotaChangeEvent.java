package utils.events;


import validators.Nota;

public class NotaChangeEvent implements Event {
    private ChangeEventType type;
    private Nota data;

    public NotaChangeEvent(ChangeEventType type, Nota data) {
        this.type = type;
        this.data = data;
    }

    public ChangeEventType getType() {
        return type;
    }

    public Nota getData() {
        return data;
    }

}