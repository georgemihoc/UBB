
namespace Lab10.Repository
{
    class JucatorInFileRepository : InFileRepository<string, Jucator>
    {

        public JucatorInFileRepository( string fileName) : base(fileName, EntityToFileMapping.CreateJucator)
        {
            
        }

    }

}