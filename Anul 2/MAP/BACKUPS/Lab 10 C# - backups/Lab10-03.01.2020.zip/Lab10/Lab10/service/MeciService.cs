using Curs12.Repository;
using System.Collections.Generic;
using System.Linq;

namespace Lab10.Service
{
    public class MeciService
    {
        private IRepository<string, Meci> repo;

        public MeciService(IRepository<string, Meci> repo)
        {
            this.repo = repo;
        }
        
        public List<Meci> FindAllMeciuri()
        {
            return repo.FindAll().ToList();
        }
    }
}