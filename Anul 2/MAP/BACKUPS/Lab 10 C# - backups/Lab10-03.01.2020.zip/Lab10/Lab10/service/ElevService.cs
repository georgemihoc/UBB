using Curs12.Repository;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10.Service
{
    public class ElevService
    {
        private IRepository<string, Elev> repo;

        public ElevService(IRepository<string, Elev> repo)
        {
            this.repo = repo;
        }



        public List<Elev> FindAllElevi()
        {
            return repo.FindAll().ToList();
        }
    }
}