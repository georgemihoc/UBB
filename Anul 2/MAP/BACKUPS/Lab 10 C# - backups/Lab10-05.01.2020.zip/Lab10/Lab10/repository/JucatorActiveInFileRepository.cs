namespace Lab10.Repository
{
    class JucatorActivInFileRepository : InFileRepository<string, JucatorActiv>
    {

        public JucatorActivInFileRepository( string fileName) : base(fileName, EntityToFileMapping.CreateJucatorActiv)
        {
            
        }

    }

}